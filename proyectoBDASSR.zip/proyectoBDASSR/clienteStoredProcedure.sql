CREATE DEFINER=`root`@`localhost` PROCEDURE `clienteEDDIT`(
   in _idCliente int(11),
   in _nombre varchar(50),
   in _RUC int(11),
   in _direccion varchar(70),
   in _telefono int(11),
   in _tipo varchar(15)
)
BEGIN
   IF  _idCliente != 0 THEN
      UPDATE cliente      
      set nombre = _nombre,
		  RUC = _RUC,
          direccion = _direccion,
          telefono = _telefono,
          tipo = _tipo
	   WHERE idCliente = _idCliente;
	END IF;
    SELECT _idCliente AS idCliente;
END