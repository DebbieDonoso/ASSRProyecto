CREATE DEFINER=`root`@`localhost` PROCEDURE `planEDDIT`(
   in _idPlan int(11),
   in _tipo varchar(15),
   in _almacenamiento varchar(10),
   in _precioMonth int(11)
)
BEGIN
   IF  _idPlan != 0 THEN
      UPDATE plan      
      set tipo = _tipo,
		  almacenamiento = _almacenamiento,
          precioMonth = _precioMonth
	   WHERE idPlan = _idPlan;
	END IF;
    SELECT _idPlan AS idPlan;
END