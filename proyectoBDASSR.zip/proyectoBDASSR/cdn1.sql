CREATE DATABASE CDN1;  
USE CDN1;

CREATE TABLE Cliente (  
idCliente int,
nombre VARCHAR(50),
RUC int,
direccion varchar (70),
telefono int,
tipo varchar(15),  
PRIMARY KEY(idCliente)  
);    

CREATE TABLE Plan (  
idPlan int,
tipo varchar(15),
almacenamiento varchar(10),
precioMonth int,
PRIMARY KEY(idPlan)  
);    

CREATE TABLE Factura (  
idFactura int,
cliente int,
plan int,
tiempo varchar(20),
descuento int,
PRIMARY KEY(idFactura, cliente, Plan) 
);    


-- INSERCION DE REGISTROS A LAS TABLAS

insert into Cliente values (10001, 'Hey.ec', 202012345, 'Rumichaca', 2970835, 'Estandar');
insert into Cliente values (10002, 'Nobis', 202067890, 'Av. Panama', 2973028, 'Estandar');
insert into Cliente values (10003, 'SASF', 202092838, 'Av, de las Americas', 2970835, 'Estandar');
insert into Cliente values (10004, 'Global Hitts', 202009129, 'Av. 25 de Julio', 2971491, 'VIP');
insert into Cliente values (10005, 'Rennaisence', 202012673, 'Calle Olmedo 202', 2979334, 'VIP');
insert into Cliente values (10006, 'Yummy', 202076778, 'Av. Quito 501', 2975234, 'Estandar');
insert into Cliente values (10007, 'Gym Virtual', 202081230, 'Eloy Alfaro y 9 Octubre', 2970988, 'Estandar');
insert into Cliente values (10008, 'Century', 202043981, 'Pedro Carbo 101', 2970771, 'Estandar');
insert into Cliente values (10009, 'Tik Tok Ec', 202022334, 'Boyaca Edf. Xima 205', 2970547, 'Estandar');
insert into Cliente values (10010, 'Ed-modo', 202001294, 'Av. Fco. de Orellana 707', 2970792, 'Estandar');

select * from Cliente;

insert into Plan values(20001, 'Start Up', '50 Gb', 100);
insert into Plan values(20002, 'Empresas', '1 Tb', 500);
insert into Plan values(20003, 'Corporacion', '100 Tb', 2000);

select * from Plan;


insert into Factura values(30001, 10001, 20002, '1 año', 10);
insert into Factura values(30002, 10002, 20002, '2 años', 12);
insert into Factura values(30003, 10003, 20001, '3 meses', 0);
insert into Factura values(30004, 10004, 20001, '6 meses', 3);
insert into Factura values(30005, 10005, 20001, '5 años', 15);
insert into Factura values(30006, 10006, 20001, '1 año', 10);
insert into Factura values(30007, 10007, 20002, '9 meses', 5);
insert into Factura values(30008, 10008, 20003, '3 meses', 0);
insert into Factura values(30009, 10009, 20003, '2 años', 12);
insert into Factura values(30010, 10010, 20003, '1 año', 10);


select * from Factura; 

select * from cliente;
delete from cliente where idCliente= 10001;
