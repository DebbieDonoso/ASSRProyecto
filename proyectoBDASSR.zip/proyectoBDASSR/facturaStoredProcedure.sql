CREATE DEFINER=`root`@`localhost` PROCEDURE `FacturaEDDIT`(
   in _idFactura int(11),
   in _cliente int(11),
   in _plan int(11),
   in _tiempo varchar(20),
   in _descuento int(11)
)
BEGIN
   IF  _idFactura != 0 THEN
      UPDATE factura      
      set cliente = _cliente,
		  plan = _plan,
          tiempo = _tiempo,
          descuento = _descuento
	   WHERE idFactura = _idFactura;
	END IF;
    SELECT _idFactura AS idFactura;
END