const dbConnection = require('../config/databaseCon');
const connection = dbConnection();

let getPlan = async (req,res)=>{
    await connection.query("select * from plan", (err,result)=>{
        if (result)    
            res.send(result);

        else
            res.status(500).send(err);
    });
}


let getPlanid =  async (req,res) => {
    const { id } = req.params;
    //var _id = require('mysql').ObjectID(id);
    connection.query(`SELECT * FROM plan WHERE idPlan =  ${id}` , (err,result) => {
        if (result)  {
            res.send(result);
        }
        
        else{
            console.log(err);
        }
        
    });
}

let addPlan = async (req,res)=>{
    const {idPlan,tipo,almacenamiento,precioMonth} = req.body
    await connection.query(`INSERT INTO PLAN VALUES(${idPlan}, '${tipo}' , '${almacenamiento}' , ${precioMonth})`, (err,result)=>{
        
        if (result)    
            res.send({idPlan,tipo,almacenamiento,precioMonth});
        else
            res.status(500).send(err);
    });
}


let deletePlan = async (req,res) => {
    const { id } = req.params;
    //const {idCliente,nombre,RUC,direccion,telefono,tipo} = req.body
    await connection.query(`DELETE FROM PLAN WHERE idPlan = ${id}` , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Plan eliminado' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}


let putPlan = async (req,res) => {
    const { id } = req.params;
    const {tipo,almacenamiento,precioMonth} = req.body
    const query = 'CALL planEDDIT(?,?,?,?)'
    await connection.query(query,[id, tipo, almacenamiento, precioMonth] , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Plan actualizado' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}




module.exports = {
    getPlan,
    addPlan,
    getPlanid,
    deletePlan,
    putPlan
}
