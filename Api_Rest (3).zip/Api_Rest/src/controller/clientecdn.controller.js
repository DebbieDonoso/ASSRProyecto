const dbConnection = require('../config/databaseCon');
const connection = dbConnection();




let getCliente = async (req,res) =>{
    await connection.query("select * from cliente", (err,result) =>{
        if(result)
           res.send(result);
        else
           res.status(500).send(err);


});



}


let getClienteid =  async (req,res) => {
    const { id } = req.params;
    //var _id = require('mysql').ObjectID(id);
    connection.query(`SELECT * FROM cliente WHERE idCliente =  ${id}` , (err,result) => {
        if (result)  {
            res.send(result);
        }
        
        else{
            console.log(err);
        }
        
    });
}

let addCliente = async (req,res)=>{
    const {idCliente,nombre,RUC,direccion,telefono,tipo} = req.body
    await connection.query(`INSERT INTO CLIENTE VALUES(${idCliente}, '${nombre}', ${RUC}, '${direccion}', ${telefono}, '${tipo}')`, (err,result)=>{
        
        if (result)    
            res.send({idCliente,nombre,RUC,direccion,telefono,tipo});
        else
            res.status(500).send(err);
    });
}

let deleteCliente = async (req,res) => {
    const { id2 } = req.params;
    const { id } = req.params;
    //const {idCliente,nombre,RUC,direccion,telefono,tipo} = req.body
    await connection.query(`DELETE FROM CLIENTE WHERE RUC = ${id} AND idCliente = ${id2}` , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Cliente eliminado' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}


let putCliente = async (req,res) => {
    const { id } = req.params;
    const {nombre,RUC,direccion,telefono,tipo} = req.body
    const query = 'CALL clienteEDDIT(?,?,?,?,?,?)'
    await connection.query(query,[id, nombre, RUC, direccion, telefono, tipo] , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Cliente actualizado' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}



module.exports = {
    getClienteid,
    addCliente,
    deleteCliente,
    getCliente,
    putCliente
}
