const dbConnection = require('../config/databaseCon');
const connection = dbConnection();

let getFactura = async (req,res)=>{
    await connection.query("select * from factura", (err,result)=>{
        if (result)    
            res.send(result);

        else
            res.status(500).send(err);
    });
}


let getFacturaid =  async (req,res) => {
    const { id } = req.params;
    //var _id = require('mysql').ObjectID(id);
    connection.query(`SELECT * FROM factura WHERE idFactura =  ${id}` , (err,result) => {
        if (result)  {
            res.send(result);
        }
        
        else{
            console.log(err);
        }
        
    });
}



let addFactura = async (req,res)=>{
    const {idFactura,cliente,plan,tiempo,descuento} = req.body
    await connection.query(`INSERT INTO FACTURA VALUES(${idFactura}, ${cliente}, ${plan}, '${tiempo}', ${descuento})`, (err,result)=>{
        
        if (result)    
            res.send({idFactura,cliente,plan,tiempo,descuento});
        else
            res.status(500).send(err);
    });
}


let deleteFactura = async (req,res) => {
    const { id2 } = req.params;
    const { id } = req.params;
    //const {idCliente,nombre,RUC,direccion,telefono,tipo} = req.body
    await connection.query(`DELETE FROM FACTURA WHERE idFactura = ${id} AND cliente = ${id2}` , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Factura eliminada' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}


let putFactura = async (req,res) => {
    const { id } = req.params;
    const {cliente,plan,tiempo,descuento} = req.body
    const query = 'CALL FacturaEDDIT(?,?,?,?,?)'
    await connection.query(query,[id, cliente, plan, tiempo, descuento] , (err,result) => {

        if (result)  
            //res.remove({idCliente,nombre,RUC,direccion,telefono,tipo});
            //res.remove(result);
            res.send({status:'Factura actualizada' });
        
        else
            res.status(500).send(err);
        
        
    });
    
}


module.exports = {
    getFactura,
    addFactura,
    getFacturaid,
    deleteFactura,
    putFactura
}
