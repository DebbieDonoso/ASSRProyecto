const mysql = require('mysql');

module.exports = () => {
    return mysql.createConnection({
        user:'root',
        database:'cdn1',
    });
    }
