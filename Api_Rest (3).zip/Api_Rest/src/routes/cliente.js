const {Router} = require("express");
const router = Router();
const{ getCliente ,getClienteid, addCliente, deleteCliente , putCliente} =  require("../controller/clientecdn.controller");

router.get('/:id', getClienteid);
router.get('/', getCliente);

router.post("/",addCliente);
router.delete('/:id/:id2', deleteCliente);

router.put('/:id', putCliente);


module.exports = router;
