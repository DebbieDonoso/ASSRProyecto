const {Router} = require("express");
const router = Router();
const{ getPlan, addPlan,getPlanid,deletePlan,putPlan } =  require("../controller/plancdn.controller");

router.get('/', getPlan);
router.get('/:id', getPlanid);

router.post("/",addPlan);
router.delete('/:id',deletePlan);

router.put('/:id',putPlan);

module.exports = router;