const {Router} = require("express");
const router = Router();
const{ getFactura, addFactura,getFacturaid,deleteFactura,putFactura } =  require("../controller/facturacdn.controller");

router.get('/', getFactura);
router.get('/:id', getFacturaid);

router.post("/",addFactura);

router.delete('/:id/:id2',deleteFactura);
router.put('/:id',putFactura);

module.exports = router;